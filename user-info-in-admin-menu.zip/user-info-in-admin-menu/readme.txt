=== User Info In Admin Menu ===
Contributors: josephbydesign
Tags: user info, admin, menu, admin-menu, cms, avatar, logout, user profile, josephbydesign, YOBD Digital
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: trunk
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Add current user info at the top of the admin menu

== Description ==

Want to give you or your clients a better experience? This plugin will easily add the current user avatar and links to there profile and a logout link at the top of the Admin menu. This plugin is only for Admins not for general users. A great way to add a face lift to your or your clients backend!

== Installation ==

1. Upload `user_info_in_admin_menu.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Be awesome!

== Screenshots ==

1. `/assets/screenshot-1.png`


